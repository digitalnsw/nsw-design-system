export function copyToClipboard(text: any): Promise<any>;
export function uniqueId(prefix: any): string;
export function focusObjectGenerator(arr: any): {
    all: any;
    first: any;
    last: any;
    length: any;
};
export function getFocusableElement(el: any): {
    all: any;
    first: any;
    last: any;
    length: any;
};
export function getFocusableElementBySelector(id: any, selectorArr: any): {
    all: any;
    first: any;
    last: any;
    length: any;
};
export function trapTabKey(event: any, focusObject: any): boolean;
export function whichTransitionEvent(): any;
export function validateUrl(raw: any, fallback?: string): string;
export function popupWindow(url: any, width: any, height: any): void;
export function setAriaDisabled(element: any, isDisabled: any, className?: string): void;
export function isAriaDisabled(element: any): any;
